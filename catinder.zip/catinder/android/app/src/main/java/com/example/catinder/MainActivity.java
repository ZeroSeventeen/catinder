package com.example.catinder;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
