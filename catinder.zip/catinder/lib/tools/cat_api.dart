
class CatApi {
  CatApi._();
  static const String baseUrl = "https://api.thecatapi.com/v1";
  static const String getCats = "$baseUrl/images/search/";

  static const String apikey = "live_YNAGhWVqPKPwgF8A0CH7OObxU2e5UirkA9xDUTlcI5e4Zyjpz4nk2KG1AUNQdSEr";
  static const String request = "$getCats?has_breeds=1&api_key=$apikey";

}